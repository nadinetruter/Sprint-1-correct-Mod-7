from django.urls import path
from . import views

urlpatterns = [
    path('report/activities', views.activities_report_page, name='activities_report'),
    path('report/sprint', views.sprint_report_page, name='sprint_report'),
    path('report/reflections',views.reflections_report_page,name='reflections_report'),

]
