from django.shortcuts import render


def activities_report_page(request):
    return render(request, 'activities_report.html', {})


def sprint_report_page(request):
    return render(request, 'sprint_report.html', {})


def reflections_report_page(request):
    return render(request, 'reflections_report.html', {})





